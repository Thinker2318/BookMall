if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LoginPage_Params {
    username?: string;
    password?: string;
}
import router from "@ohos:router";
export class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LoginPage_Params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
    }
    updateStateVars(params: LoginPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Login.ets(10:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundImage({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.example.finalreport2", "moduleName": "entry" }, ImageRepeat.NoRepeat);
            Column.backgroundImageSize(ImageSize.Cover);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Logo展示
            Image.create({ "id": 16777225, "type": 20000, params: [], "bundleName": "com.example.finalreport2", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Login.ets(12:7)", "entry");
            // Logo展示
            Image.width(120);
            // Logo展示
            Image.height(120);
            // Logo展示
            Image.margin({ top: 60 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 登录表单
            TextInput.create({ placeholder: '请输入用户名' });
            TextInput.debugLine("entry/src/main/ets/pages/Login.ets(18:7)", "entry");
            // 登录表单
            TextInput.width('80%');
            // 登录表单
            TextInput.height(50);
            // 登录表单
            TextInput.margin({ top: 40 });
            // 登录表单
            TextInput.onChange((value: string) => {
                this.username = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入密码' });
            TextInput.debugLine("entry/src/main/ets/pages/Login.ets(26:7)", "entry");
            TextInput.width('80%');
            TextInput.height(50);
            TextInput.margin({ top: 20 });
            TextInput.type(InputType.Password);
            TextInput.onChange((value: string) => {
                this.password = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 登录按钮
            Button.createWithLabel('登 录');
            Button.debugLine("entry/src/main/ets/pages/Login.ets(36:7)", "entry");
            // 登录按钮
            Button.width('80%');
            // 登录按钮
            Button.height(50);
            // 登录按钮
            Button.margin({ top: 40 });
            // 登录按钮
            Button.backgroundColor('#007DFF');
            // 登录按钮
            Button.onClick(() => {
                if (this.username && this.password) {
                    // 简单登录验证
                    //router.pushUrl({ url: 'pages/Home' });
                    router.pushUrl({
                        url: 'pages/Home',
                        params: { username: this.username } // 可携带参数
                    });
                }
            });
        }, Button);
        // 登录按钮
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LoginPage";
    }
}
registerNamedRoute(() => new LoginPage(undefined, {}), "", { bundleName: "com.example.finalreport2", moduleName: "entry", pagePath: "pages/Login", pageFullPath: "entry/src/main/ets/pages/Login", integratedHsp: "false", moduleType: "followWithHap" });
